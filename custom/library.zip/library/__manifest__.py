{
    'name': 'Library Mgmt',
    'category': 'Sales',
    'application': True,
    'data' : [
            'security/ir.model.access.csv',
            'views/books_menus.xml',
            'views/books_views.xml'
        ],

}
